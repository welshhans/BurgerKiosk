﻿namespace BurgerKiosk
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label21 = new System.Windows.Forms.Label();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.submitButton = new System.Windows.Forms.Button();
            this.cheeseListBox2 = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.carmellabel = new System.Windows.Forms.Label();
            this.jalapenolabel = new System.Windows.Forms.Label();
            this.egglabel = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.stringOnionNumber = new System.Windows.Forms.NumericUpDown();
            this.caramelOnionNumber = new System.Windows.Forms.NumericUpDown();
            this.jalapenoNumber = new System.Windows.Forms.NumericUpDown();
            this.eggNumber = new System.Windows.Forms.NumericUpDown();
            this.guacNumber = new System.Windows.Forms.NumericUpDown();
            this.baconNumber = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pickleNumber = new System.Windows.Forms.NumericUpDown();
            this.onionNumber = new System.Windows.Forms.NumericUpDown();
            this.tomatoNumber = new System.Windows.Forms.NumericUpDown();
            this.lettuceNumber = new System.Windows.Forms.NumericUpDown();
            this.garlicNumber = new System.Windows.Forms.NumericUpDown();
            this.mayoNumber = new System.Windows.Forms.NumericUpDown();
            this.mustardNumber = new System.Windows.Forms.NumericUpDown();
            this.ketchupNumber = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.cheeseListBox1 = new System.Windows.Forms.ListBox();
            this.noBunRadio = new System.Windows.Forms.RadioButton();
            this.pretBunRadio = new System.Windows.Forms.RadioButton();
            this.brioBunRadio = new System.Windows.Forms.RadioButton();
            this.regBunRadio = new System.Windows.Forms.RadioButton();
            this.vegBurgerBox = new System.Windows.Forms.CheckBox();
            this.turkeyBurgerBox = new System.Windows.Forms.CheckBox();
            this.beefBurgerBox = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.burgerGroupBox = new System.Windows.Forms.GroupBox();
            this.bunGroupBox = new System.Windows.Forms.GroupBox();
            this.cheeseGroupBox = new System.Windows.Forms.GroupBox();
            this.toppingsGroupBox = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.extrasGroupBox = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stringOnionNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.caramelOnionNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jalapenoNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eggNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guacNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baconNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pickleNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onionNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tomatoNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lettuceNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.garlicNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayoNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mustardNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ketchupNumber)).BeginInit();
            this.burgerGroupBox.SuspendLayout();
            this.bunGroupBox.SuspendLayout();
            this.cheeseGroupBox.SuspendLayout();
            this.toppingsGroupBox.SuspendLayout();
            this.extrasGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(78, 544);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(66, 25);
            this.label21.TabIndex = 125;
            this.label21.Text = "Total:";
            // 
            // totalTextBox
            // 
            this.totalTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalTextBox.Location = new System.Drawing.Point(150, 542);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.Size = new System.Drawing.Size(128, 31);
            this.totalTextBox.TabIndex = 124;
            // 
            // pictureBox1
            // 
            this.pictureBox1.AccessibleName = "burger";
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(311, 251);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(278, 227);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 123;
            this.pictureBox1.TabStop = false;
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(627, 541);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(90, 30);
            this.clearButton.TabIndex = 122;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // submitButton
            // 
            this.submitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitButton.Location = new System.Drawing.Point(392, 541);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(90, 30);
            this.submitButton.TabIndex = 121;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // cheeseListBox2
            // 
            this.cheeseListBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheeseListBox2.FormattingEnabled = true;
            this.cheeseListBox2.ItemHeight = 20;
            this.cheeseListBox2.Items.AddRange(new object[] {
            "American",
            "Cheddar",
            "Swiss",
            "Pepper Jack",
            "None"});
            this.cheeseListBox2.Location = new System.Drawing.Point(94, 58);
            this.cheeseListBox2.Name = "cheeseListBox2";
            this.cheeseListBox2.Size = new System.Drawing.Size(100, 24);
            this.cheeseListBox2.TabIndex = 120;
            this.cheeseListBox2.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(13, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 20);
            this.label8.TabIndex = 119;
            this.label8.Text = "2 = $0.25";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(20, 32);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 20);
            this.label18.TabIndex = 118;
            this.label18.Text = "1 = Free";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(51, 172);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 20);
            this.label10.TabIndex = 117;
            this.label10.Text = "Onion Strings";
            // 
            // carmellabel
            // 
            this.carmellabel.AutoSize = true;
            this.carmellabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carmellabel.Location = new System.Drawing.Point(51, 149);
            this.carmellabel.Name = "carmellabel";
            this.carmellabel.Size = new System.Drawing.Size(142, 20);
            this.carmellabel.TabIndex = 116;
            this.carmellabel.Text = "Carmelized Onions";
            // 
            // jalapenolabel
            // 
            this.jalapenolabel.AutoSize = true;
            this.jalapenolabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jalapenolabel.Location = new System.Drawing.Point(51, 126);
            this.jalapenolabel.Name = "jalapenolabel";
            this.jalapenolabel.Size = new System.Drawing.Size(82, 20);
            this.jalapenolabel.TabIndex = 115;
            this.jalapenolabel.Text = "Jalapenos";
            // 
            // egglabel
            // 
            this.egglabel.AutoSize = true;
            this.egglabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.egglabel.Location = new System.Drawing.Point(51, 103);
            this.egglabel.Name = "egglabel";
            this.egglabel.Size = new System.Drawing.Size(78, 20);
            this.egglabel.TabIndex = 114;
            this.egglabel.Text = "Fried Egg";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(51, 80);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(91, 20);
            this.label24.TabIndex = 113;
            this.label24.Text = "Guacamole";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(51, 57);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(55, 20);
            this.label25.TabIndex = 112;
            this.label25.Text = "Bacon";
            // 
            // stringOnionNumber
            // 
            this.stringOnionNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stringOnionNumber.Location = new System.Drawing.Point(10, 170);
            this.stringOnionNumber.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.stringOnionNumber.Name = "stringOnionNumber";
            this.stringOnionNumber.Size = new System.Drawing.Size(34, 26);
            this.stringOnionNumber.TabIndex = 111;
            this.stringOnionNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // caramelOnionNumber
            // 
            this.caramelOnionNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.caramelOnionNumber.Location = new System.Drawing.Point(10, 147);
            this.caramelOnionNumber.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.caramelOnionNumber.Name = "caramelOnionNumber";
            this.caramelOnionNumber.Size = new System.Drawing.Size(34, 26);
            this.caramelOnionNumber.TabIndex = 110;
            this.caramelOnionNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // jalapenoNumber
            // 
            this.jalapenoNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jalapenoNumber.Location = new System.Drawing.Point(10, 124);
            this.jalapenoNumber.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.jalapenoNumber.Name = "jalapenoNumber";
            this.jalapenoNumber.Size = new System.Drawing.Size(34, 26);
            this.jalapenoNumber.TabIndex = 109;
            this.jalapenoNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // eggNumber
            // 
            this.eggNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eggNumber.Location = new System.Drawing.Point(10, 101);
            this.eggNumber.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.eggNumber.Name = "eggNumber";
            this.eggNumber.Size = new System.Drawing.Size(34, 26);
            this.eggNumber.TabIndex = 108;
            this.eggNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // guacNumber
            // 
            this.guacNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guacNumber.Location = new System.Drawing.Point(10, 78);
            this.guacNumber.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.guacNumber.Name = "guacNumber";
            this.guacNumber.Size = new System.Drawing.Size(34, 26);
            this.guacNumber.TabIndex = 107;
            this.guacNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // baconNumber
            // 
            this.baconNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.baconNumber.Location = new System.Drawing.Point(10, 55);
            this.baconNumber.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.baconNumber.Name = "baconNumber";
            this.baconNumber.Size = new System.Drawing.Size(34, 26);
            this.baconNumber.TabIndex = 106;
            this.baconNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(6, 28);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(76, 20);
            this.label20.TabIndex = 105;
            this.label20.Text = "(+ $1.00):";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 49);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(75, 20);
            this.label19.TabIndex = 104;
            this.label19.Text = "2 = $7.00";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(51, 223);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 20);
            this.label17.TabIndex = 103;
            this.label17.Text = "Pickle";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(51, 200);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(51, 20);
            this.label16.TabIndex = 102;
            this.label16.Text = "Onion";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(51, 177);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 20);
            this.label15.TabIndex = 101;
            this.label15.Text = "Tomato";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(51, 154);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 20);
            this.label14.TabIndex = 100;
            this.label14.Text = "Lettuce";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(51, 131);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 20);
            this.label13.TabIndex = 99;
            this.label13.Text = "Garlic Aioli";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(51, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 20);
            this.label12.TabIndex = 98;
            this.label12.Text = "Mayo";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(51, 85);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 20);
            this.label11.TabIndex = 97;
            this.label11.Text = "Mustard";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(51, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 20);
            this.label9.TabIndex = 96;
            this.label9.Text = "Ketchup";
            // 
            // pickleNumber
            // 
            this.pickleNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pickleNumber.Location = new System.Drawing.Point(10, 221);
            this.pickleNumber.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.pickleNumber.Name = "pickleNumber";
            this.pickleNumber.Size = new System.Drawing.Size(34, 26);
            this.pickleNumber.TabIndex = 95;
            this.pickleNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // onionNumber
            // 
            this.onionNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.onionNumber.Location = new System.Drawing.Point(10, 198);
            this.onionNumber.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.onionNumber.Name = "onionNumber";
            this.onionNumber.Size = new System.Drawing.Size(34, 26);
            this.onionNumber.TabIndex = 94;
            this.onionNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // tomatoNumber
            // 
            this.tomatoNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tomatoNumber.Location = new System.Drawing.Point(10, 175);
            this.tomatoNumber.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.tomatoNumber.Name = "tomatoNumber";
            this.tomatoNumber.Size = new System.Drawing.Size(34, 26);
            this.tomatoNumber.TabIndex = 93;
            this.tomatoNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // lettuceNumber
            // 
            this.lettuceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lettuceNumber.Location = new System.Drawing.Point(10, 152);
            this.lettuceNumber.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.lettuceNumber.Name = "lettuceNumber";
            this.lettuceNumber.Size = new System.Drawing.Size(34, 26);
            this.lettuceNumber.TabIndex = 92;
            this.lettuceNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // garlicNumber
            // 
            this.garlicNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.garlicNumber.Location = new System.Drawing.Point(10, 129);
            this.garlicNumber.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.garlicNumber.Name = "garlicNumber";
            this.garlicNumber.Size = new System.Drawing.Size(34, 26);
            this.garlicNumber.TabIndex = 91;
            this.garlicNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // mayoNumber
            // 
            this.mayoNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mayoNumber.Location = new System.Drawing.Point(10, 106);
            this.mayoNumber.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.mayoNumber.Name = "mayoNumber";
            this.mayoNumber.Size = new System.Drawing.Size(34, 26);
            this.mayoNumber.TabIndex = 90;
            this.mayoNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // mustardNumber
            // 
            this.mustardNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mustardNumber.Location = new System.Drawing.Point(10, 83);
            this.mustardNumber.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.mustardNumber.Name = "mustardNumber";
            this.mustardNumber.Size = new System.Drawing.Size(34, 26);
            this.mustardNumber.TabIndex = 89;
            this.mustardNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // ketchupNumber
            // 
            this.ketchupNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ketchupNumber.Location = new System.Drawing.Point(10, 60);
            this.ketchupNumber.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.ketchupNumber.Name = "ketchupNumber";
            this.ketchupNumber.Size = new System.Drawing.Size(34, 26);
            this.ketchupNumber.TabIndex = 88;
            this.ketchupNumber.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 20);
            this.label7.TabIndex = 87;
            this.label7.Text = "1 = $4.00";
            // 
            // cheeseListBox1
            // 
            this.cheeseListBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheeseListBox1.FormattingEnabled = true;
            this.cheeseListBox1.ItemHeight = 20;
            this.cheeseListBox1.Items.AddRange(new object[] {
            "American",
            "Cheddar",
            "Swiss",
            "Pepper Jack",
            "None"});
            this.cheeseListBox1.Location = new System.Drawing.Point(94, 28);
            this.cheeseListBox1.Name = "cheeseListBox1";
            this.cheeseListBox1.Size = new System.Drawing.Size(100, 24);
            this.cheeseListBox1.TabIndex = 84;
            this.cheeseListBox1.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // noBunRadio
            // 
            this.noBunRadio.AutoSize = true;
            this.noBunRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noBunRadio.Location = new System.Drawing.Point(10, 134);
            this.noBunRadio.Name = "noBunRadio";
            this.noBunRadio.Size = new System.Drawing.Size(65, 24);
            this.noBunRadio.TabIndex = 82;
            this.noBunRadio.TabStop = true;
            this.noBunRadio.Text = "None";
            this.noBunRadio.UseVisualStyleBackColor = true;
            this.noBunRadio.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // pretBunRadio
            // 
            this.pretBunRadio.AutoSize = true;
            this.pretBunRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pretBunRadio.Location = new System.Drawing.Point(10, 110);
            this.pretBunRadio.Name = "pretBunRadio";
            this.pretBunRadio.Size = new System.Drawing.Size(76, 24);
            this.pretBunRadio.TabIndex = 81;
            this.pretBunRadio.TabStop = true;
            this.pretBunRadio.Text = "Pretzel";
            this.pretBunRadio.UseVisualStyleBackColor = true;
            this.pretBunRadio.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // brioBunRadio
            // 
            this.brioBunRadio.AutoSize = true;
            this.brioBunRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brioBunRadio.Location = new System.Drawing.Point(10, 86);
            this.brioBunRadio.Name = "brioBunRadio";
            this.brioBunRadio.Size = new System.Drawing.Size(81, 24);
            this.brioBunRadio.TabIndex = 80;
            this.brioBunRadio.TabStop = true;
            this.brioBunRadio.Text = "Brioche";
            this.brioBunRadio.UseVisualStyleBackColor = true;
            this.brioBunRadio.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // regBunRadio
            // 
            this.regBunRadio.AutoSize = true;
            this.regBunRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regBunRadio.Location = new System.Drawing.Point(10, 62);
            this.regBunRadio.Name = "regBunRadio";
            this.regBunRadio.Size = new System.Drawing.Size(83, 24);
            this.regBunRadio.TabIndex = 79;
            this.regBunRadio.TabStop = true;
            this.regBunRadio.Text = "Regular";
            this.regBunRadio.UseVisualStyleBackColor = true;
            this.regBunRadio.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // vegBurgerBox
            // 
            this.vegBurgerBox.AutoSize = true;
            this.vegBurgerBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vegBurgerBox.Location = new System.Drawing.Point(19, 126);
            this.vegBurgerBox.Name = "vegBurgerBox";
            this.vegBurgerBox.Size = new System.Drawing.Size(78, 24);
            this.vegBurgerBox.TabIndex = 77;
            this.vegBurgerBox.Text = "Veggie";
            this.vegBurgerBox.UseVisualStyleBackColor = true;
            this.vegBurgerBox.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // turkeyBurgerBox
            // 
            this.turkeyBurgerBox.AutoSize = true;
            this.turkeyBurgerBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.turkeyBurgerBox.Location = new System.Drawing.Point(19, 103);
            this.turkeyBurgerBox.Name = "turkeyBurgerBox";
            this.turkeyBurgerBox.Size = new System.Drawing.Size(75, 24);
            this.turkeyBurgerBox.TabIndex = 76;
            this.turkeyBurgerBox.Text = "Turkey";
            this.turkeyBurgerBox.UseVisualStyleBackColor = true;
            this.turkeyBurgerBox.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // beefBurgerBox
            // 
            this.beefBurgerBox.AutoSize = true;
            this.beefBurgerBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.beefBurgerBox.Location = new System.Drawing.Point(19, 80);
            this.beefBurgerBox.Name = "beefBurgerBox";
            this.beefBurgerBox.Size = new System.Drawing.Size(62, 24);
            this.beefBurgerBox.TabIndex = 75;
            this.beefBurgerBox.Text = "Beef";
            this.beefBurgerBox.UseVisualStyleBackColor = true;
            this.beefBurgerBox.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, -26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 24);
            this.label1.TabIndex = 73;
            this.label1.Text = "Name:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTextBox.Location = new System.Drawing.Point(115, -27);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(196, 26);
            this.nameTextBox.TabIndex = 72;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(29, 32);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(79, 25);
            this.label22.TabIndex = 127;
            this.label22.Text = "Name:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(111, 31);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(196, 26);
            this.textBox1.TabIndex = 126;
            // 
            // burgerGroupBox
            // 
            this.burgerGroupBox.Controls.Add(this.beefBurgerBox);
            this.burgerGroupBox.Controls.Add(this.turkeyBurgerBox);
            this.burgerGroupBox.Controls.Add(this.label7);
            this.burgerGroupBox.Controls.Add(this.label19);
            this.burgerGroupBox.Controls.Add(this.vegBurgerBox);
            this.burgerGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.burgerGroupBox.Location = new System.Drawing.Point(101, 80);
            this.burgerGroupBox.Name = "burgerGroupBox";
            this.burgerGroupBox.Size = new System.Drawing.Size(165, 159);
            this.burgerGroupBox.TabIndex = 128;
            this.burgerGroupBox.TabStop = false;
            this.burgerGroupBox.Text = "Burger Type:";
            // 
            // bunGroupBox
            // 
            this.bunGroupBox.Controls.Add(this.label20);
            this.bunGroupBox.Controls.Add(this.regBunRadio);
            this.bunGroupBox.Controls.Add(this.brioBunRadio);
            this.bunGroupBox.Controls.Add(this.pretBunRadio);
            this.bunGroupBox.Controls.Add(this.noBunRadio);
            this.bunGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunGroupBox.Location = new System.Drawing.Point(618, 80);
            this.bunGroupBox.Name = "bunGroupBox";
            this.bunGroupBox.Size = new System.Drawing.Size(142, 171);
            this.bunGroupBox.TabIndex = 129;
            this.bunGroupBox.TabStop = false;
            this.bunGroupBox.Text = "Bun:";
            // 
            // cheeseGroupBox
            // 
            this.cheeseGroupBox.Controls.Add(this.label18);
            this.cheeseGroupBox.Controls.Add(this.cheeseListBox1);
            this.cheeseGroupBox.Controls.Add(this.label8);
            this.cheeseGroupBox.Controls.Add(this.cheeseListBox2);
            this.cheeseGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheeseGroupBox.Location = new System.Drawing.Point(331, 98);
            this.cheeseGroupBox.Name = "cheeseGroupBox";
            this.cheeseGroupBox.Size = new System.Drawing.Size(222, 116);
            this.cheeseGroupBox.TabIndex = 130;
            this.cheeseGroupBox.TabStop = false;
            this.cheeseGroupBox.Text = "Cheese:";
            // 
            // toppingsGroupBox
            // 
            this.toppingsGroupBox.Controls.Add(this.label3);
            this.toppingsGroupBox.Controls.Add(this.ketchupNumber);
            this.toppingsGroupBox.Controls.Add(this.mustardNumber);
            this.toppingsGroupBox.Controls.Add(this.mayoNumber);
            this.toppingsGroupBox.Controls.Add(this.garlicNumber);
            this.toppingsGroupBox.Controls.Add(this.lettuceNumber);
            this.toppingsGroupBox.Controls.Add(this.tomatoNumber);
            this.toppingsGroupBox.Controls.Add(this.onionNumber);
            this.toppingsGroupBox.Controls.Add(this.pickleNumber);
            this.toppingsGroupBox.Controls.Add(this.label9);
            this.toppingsGroupBox.Controls.Add(this.label11);
            this.toppingsGroupBox.Controls.Add(this.label12);
            this.toppingsGroupBox.Controls.Add(this.label13);
            this.toppingsGroupBox.Controls.Add(this.label14);
            this.toppingsGroupBox.Controls.Add(this.label15);
            this.toppingsGroupBox.Controls.Add(this.label16);
            this.toppingsGroupBox.Controls.Add(this.label17);
            this.toppingsGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toppingsGroupBox.Location = new System.Drawing.Point(101, 251);
            this.toppingsGroupBox.Name = "toppingsGroupBox";
            this.toppingsGroupBox.Size = new System.Drawing.Size(165, 263);
            this.toppingsGroupBox.TabIndex = 131;
            this.toppingsGroupBox.TabStop = false;
            this.toppingsGroupBox.Text = "Toppings:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 20);
            this.label3.TabIndex = 106;
            this.label3.Text = "(+ $0.05 after first):";
            // 
            // extrasGroupBox
            // 
            this.extrasGroupBox.Controls.Add(this.label2);
            this.extrasGroupBox.Controls.Add(this.label25);
            this.extrasGroupBox.Controls.Add(this.baconNumber);
            this.extrasGroupBox.Controls.Add(this.guacNumber);
            this.extrasGroupBox.Controls.Add(this.eggNumber);
            this.extrasGroupBox.Controls.Add(this.jalapenoNumber);
            this.extrasGroupBox.Controls.Add(this.caramelOnionNumber);
            this.extrasGroupBox.Controls.Add(this.stringOnionNumber);
            this.extrasGroupBox.Controls.Add(this.label24);
            this.extrasGroupBox.Controls.Add(this.egglabel);
            this.extrasGroupBox.Controls.Add(this.jalapenolabel);
            this.extrasGroupBox.Controls.Add(this.carmellabel);
            this.extrasGroupBox.Controls.Add(this.label10);
            this.extrasGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extrasGroupBox.Location = new System.Drawing.Point(618, 286);
            this.extrasGroupBox.Name = "extrasGroupBox";
            this.extrasGroupBox.Size = new System.Drawing.Size(191, 228);
            this.extrasGroupBox.TabIndex = 132;
            this.extrasGroupBox.TabStop = false;
            this.extrasGroupBox.Text = "Extras:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 20);
            this.label2.TabIndex = 118;
            this.label2.Text = "(+ $0.50 each):";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 614);
            this.Controls.Add(this.extrasGroupBox);
            this.Controls.Add(this.toppingsGroupBox);
            this.Controls.Add(this.cheeseGroupBox);
            this.Controls.Add(this.bunGroupBox);
            this.Controls.Add(this.burgerGroupBox);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.totalTextBox);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nameTextBox);
            this.Name = "Form1";
            this.Text = "Burger Order Form";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stringOnionNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.caramelOnionNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jalapenoNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eggNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guacNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baconNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pickleNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onionNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tomatoNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lettuceNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.garlicNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayoNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mustardNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ketchupNumber)).EndInit();
            this.burgerGroupBox.ResumeLayout(false);
            this.burgerGroupBox.PerformLayout();
            this.bunGroupBox.ResumeLayout(false);
            this.bunGroupBox.PerformLayout();
            this.cheeseGroupBox.ResumeLayout(false);
            this.cheeseGroupBox.PerformLayout();
            this.toppingsGroupBox.ResumeLayout(false);
            this.toppingsGroupBox.PerformLayout();
            this.extrasGroupBox.ResumeLayout(false);
            this.extrasGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.ListBox cheeseListBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label carmellabel;
        private System.Windows.Forms.Label jalapenolabel;
        private System.Windows.Forms.Label egglabel;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown stringOnionNumber;
        private System.Windows.Forms.NumericUpDown caramelOnionNumber;
        private System.Windows.Forms.NumericUpDown jalapenoNumber;
        private System.Windows.Forms.NumericUpDown eggNumber;
        private System.Windows.Forms.NumericUpDown guacNumber;
        private System.Windows.Forms.NumericUpDown baconNumber;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown pickleNumber;
        private System.Windows.Forms.NumericUpDown onionNumber;
        private System.Windows.Forms.NumericUpDown tomatoNumber;
        private System.Windows.Forms.NumericUpDown lettuceNumber;
        private System.Windows.Forms.NumericUpDown garlicNumber;
        private System.Windows.Forms.NumericUpDown mayoNumber;
        private System.Windows.Forms.NumericUpDown mustardNumber;
        private System.Windows.Forms.NumericUpDown ketchupNumber;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox cheeseListBox1;
        private System.Windows.Forms.RadioButton noBunRadio;
        private System.Windows.Forms.RadioButton pretBunRadio;
        private System.Windows.Forms.RadioButton brioBunRadio;
        private System.Windows.Forms.RadioButton regBunRadio;
        private System.Windows.Forms.CheckBox vegBurgerBox;
        private System.Windows.Forms.CheckBox turkeyBurgerBox;
        private System.Windows.Forms.CheckBox beefBurgerBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox burgerGroupBox;
        private System.Windows.Forms.GroupBox bunGroupBox;
        private System.Windows.Forms.GroupBox cheeseGroupBox;
        private System.Windows.Forms.GroupBox toppingsGroupBox;
        private System.Windows.Forms.GroupBox extrasGroupBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}

